import cv2

recognizer=cv2.face.LBPHFaceRecognizer_create()
recognizer.read("F:\\All things\\setups\\python and visual studio code\\programs\\face detection\\trainer\\BossFaceTrained.yml")
cascadepath="F:\\All things\\setups\\python and visual studio code\\programs\\face detection\\haarcascade_frontalface_default.xml"
facecascade= cv2.CascadeClassifier(cascadepath)

font= cv2.FONT_HERSHEY_DUPLEX

id=2 #no. of person i wanna recognise

names= ['','Boss']

cam=cv2.VideoCapture(0, cv2.CAP_DSHOW)
cam.set(3,640)
cam.set(4,480)

#defining min window size to be considered as a face

minW=0.1*cam.get(3)
minH=0.1*cam.get(4)

flag=True

while flag:
    ret , img = cam.read()
    img=cv2.flip(img,1)
    converted_im= cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=facecascade.detectMultiScale(converted_im ,scaleFactor=1.2 , minNeighbors=5, minSize=(int(minW),int(minH)))

    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h), (0,255,0), 2) #drawing a rectangle here 
        Id,accuracy = recognizer.predict(converted_im[y:y+h,x:x+w])

        if (accuracy < 100 and accuracy >20) :
            Id = names[1]
            accuracy =" {0}%".format(round(100-accuracy))

        elif (accuracy < 30):
            Id="Not Recognised"
            accuracy ="{0}%".format(round(100-accuracy))

        cv2.putText(img, str(Id), (x+5,y-5), font , 1 , (255,255,255), 2)
        cv2.putText(img,  str(accuracy),(x+5,y+h-5), font , 1 , (255,255,0), 1)

        cv2.imshow('camera',img)

        k= cv2.waitKey(10) & 0xff #press Esc for exiting video
        if k==27:
            break   


print("I know who you are!!!")
cam.release()
cv2.destroyAllWindows()
