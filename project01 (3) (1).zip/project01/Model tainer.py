import cv2
import numpy as np
from PIL import Image
import os

path= "F:\\All things\\setups\\python and visual studio code\\programs\\face detection\\samples\\Boss"

recog= cv2.face.LBPHFaceRecognizer_create()
detector= cv2.CascadeClassifier("F:\\All things\\setups\\python and visual studio code\programs\\face detection\\haarcascade_frontalface_default.xml")

def Imagelabel(path):
    imagepaths=[os.path.join(path,f) for f in os.listdir(path)]
    facesamples=[]
    ids=[]

    for imagepath in imagepaths :

        gray_image= Image.open(imagepath).convert('L')
        image_array= np.array(gray_image,'uint8')

        id= int(os.path.split(imagepath)[-1].split(".")[1])
        faces= detector.detectMultiScale(image_array)

        for (x,y,w,h) in faces:
            facesamples.append(image_array[y:y+h,x:x+w])
            ids.append(id)

    return facesamples,ids

print("Face training in progress!!")

faces,ids= Imagelabel(path)
recog.train(faces,np.array(ids))

recog.write(f'F:\\All things\\setups\\python and visual studio code\\programs\\face detection\\trainer/FaceTrained.yml')

print("Face Training successfull")
print()
print()

print ("Finalizing process!!")
print("thanks for your patience")