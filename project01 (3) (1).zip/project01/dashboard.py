import tkinter as tk
from tkinter import filedialog, messagebox
import cv2
import numpy as np
import face_recognition
import pandas as pd
from datetime import datetime
from pymongo import MongoClient
from PIL import Image, ImageTk


class FaceRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Recognition and Attendance App")

        self.canvas = tk.Canvas(self.root, width=400, height=400)
        self.canvas.pack()

        self.upload_button = tk.Button(self.root, text="Upload Image", command=self.upload_image)
        self.upload_button.pack()

        self.verify_button = tk.Button(self.root, text="Verify Face", command=self.verify_face)
        self.verify_button.pack()

        self.save_button = tk.Button(self.root, text="Save Attendance to Excel", command=self.save_attendance_to_excel)
        self.save_button.pack()

        self.image_path = None
        self.known_faces = self.load_known_faces()

        # Connect to MongoDB
        self.client = MongoClient("mongodb+srv://shariquearslaan:Bcaproject30@facerecognitionbca.6avtpah.mongodb.net/?retryWrites=true&w=majority&appName=facerecognitionbca")
        self.db = self.client['bcaproject']
        self.collection = self.db['attendance']

        if 'attendance' not in self.db.list_collection_names():
            self.db.create_collection('attendance')

        # Create attendance CSV file
        self.attendance_file = 'attendance.csv'
        self.attendance_data = []

    def upload_image(self):
        self.image_path = filedialog.askopenfilename(title="Select Image",
                                                      filetypes=(("JPEG files", "*.jpg"), ("PNG files", "*.png")))
        if self.image_path:
            image = Image.open(self.image_path)
            image = image.resize((400, 400), Image.ANTIALIAS)
            self.display_image(image)

    def display_image(self, image):
        self.image_tk = ImageTk.PhotoImage(image)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.image_tk)

    def load_known_faces(self):
        # Load known faces from MongoDB
        client = MongoClient("mongodb+srv://shariquearslaan:Bcaproject30@facerecognitionbca.6avtpah.mongodb.net/?retryWrites=true&w=majority&appName=facerecognitionbca")
        db = client['bcaproject']
        collection = db['students']
        known_faces = list(collection.find({}, {"name": "arslaan", "encoding": 1, "_id": 0}))
        client.close()
        return known_faces

    def verify_face(self):
        if not self.image_path:
            messagebox.showerror("Error", "Please upload an image first.")
            return

        try:
            image = face_recognition.load_image_file(self.image_path)
            face_encodings = face_recognition.face_encodings(image)

            if len(face_encodings) == 0:
                messagebox.showerror("Error", "No face found in the uploaded image.")
                return

            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces([np.frombuffer(face['encoding'], np.float64) for face in self.known_faces], face_encoding)
                face_distances = face_recognition.face_distance([np.frombuffer(face['encoding'], np.float64) for face in self.known_faces], face_encoding)

                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    name = self.known_faces[best_match_index]['name']
                    messagebox.showinfo("Success", f"Face recognized as {name}")
                    self.record_attendance(name)
                    break
            else:
                messagebox.showinfo("Unknown Face", "The uploaded face is not recognized.")

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def record_attendance(self, name):
        now = datetime.now()
        attendance_date = now.strftime("%Y-%m-%d")
        attendance_time = now.strftime("%H:%M:%S")

        # Save to MongoDB
        attendance_data = {
            'name': name,
            'date': attendance_date,
            'time': attendance_time
        }
        self.collection.insert_one(attendance_data)

        # Save to CSV data for Excel
        self.attendance_data.append([name, attendance_date, attendance_time])

    def save_attendance_to_excel(self):
        if len(self.attendance_data) == 0:
            messagebox.showinfo("No Data", "No attendance data to save.")
            return

        df = pd.DataFrame(self.attendance_data, columns=['Name', 'Date', 'Time'])
        df.to_csv(self.attendance_file, index=False)
        messagebox.showinfo("Success", "Attendance data saved to CSV.")

    def on_closing(self):
        self.client.close()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = FaceRecognitionApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()
