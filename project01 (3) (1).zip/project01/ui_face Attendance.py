from PySide2.QtCore import (QCoreApplication, QMetaObject, QObject, QPoint,
    QRect, QSize, QUrl, Qt)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont,
    QFontDatabase, QIcon, QLinearGradient, QPalette, QPainter, QPixmap,
    QRadialGradient)
from PySide2.QtWidgets import *
# from bcaproject01 import video_capture
# import os


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1098, 743)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setStyleSheet(u"background-color:rgb(206, 213, 221)")
        self.verticalFrame = QFrame(self.centralwidget)
        self.verticalFrame.setObjectName(u"verticalFrame")
        self.verticalFrame.setGeometry(QRect(0, 0, 160, 751))
        self.verticalFrame.setStyleSheet(u"background-color:rgb(255, 255, 255)")
        self.pushButton = QPushButton(self.verticalFrame)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(30, 380, 93, 28))
        self.pushButton.setStyleSheet(u"background-color:rgb(206, 213, 221)")
        
        self.pushButton_2 = QPushButton(self.verticalFrame)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(30, 260, 93, 28))
        self.pushButton_2.setStyleSheet(u"background-color:rgb(206, 213, 221)")
        self.pushButton_3 = QPushButton(self.verticalFrame)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(30, 320, 93, 28))
        self.pushButton_3.setStyleSheet(u"background-color:rgb(206, 213, 221)")
        self.label_8 = QLabel(self.verticalFrame)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(30, 200, 91, 31))
        self.label_8.setStyleSheet(u"font: 75 12pt \"Times New Roman\";")
        self.verticalFrame1 = QFrame(self.centralwidget)
        self.verticalFrame1.setObjectName(u"verticalFrame1")
        self.verticalFrame1.setGeometry(QRect(160, 0, 941, 41))
        self.verticalFrame1.setStyleSheet(u"background-color:rgb(255, 255, 255)")
        self.verticalLayout_3 = QVBoxLayout(self.verticalFrame1)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")

        self.horizontalFrame = QFrame(self.centralwidget) #camera
        #os.system(video_capture)

        self.horizontalFrame.setObjectName(u"horizontalFrame")
        self.horizontalFrame.setGeometry(QRect(240, 110, 361, 431))
        self.horizontalFrame.setStyleSheet(u"background-color:rgb(255, 255, 255)")
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalFrame)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalFrame_2 = QFrame(self.centralwidget) 
        self.horizontalFrame_2.setObjectName(u"horizontalFrame_2")
        self.horizontalFrame_2.setGeometry(QRect(670, 110, 361, 431))
        self.horizontalFrame_2.setStyleSheet(u"background-color:rgb(255, 255, 255)")
        self.label = QLabel(self.horizontalFrame_2)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(60, 30, 191, 31))
        self.label.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        self.line = QFrame(self.horizontalFrame_2)
        self.line.setObjectName(u"line")
        self.line.setGeometry(QRect(40, 30, 16, 31))
        self.line.setMinimumSize(QSize(0, 31))
        self.line.setStyleSheet(u"background-color:rgb(245, 106, 66)")
        self.line.setFrameShape(QFrame.VLine)
        self.line.setFrameShadow(QFrame.Sunken)
        self.graphicsView = QGraphicsView(self.horizontalFrame_2)
        self.graphicsView.setObjectName(u"graphicsView")
        self.graphicsView.setGeometry(QRect(100, 80, 161, 131))
        self.label_2 = QLabel(self.horizontalFrame_2)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(20, 240, 81, 31))
        self.label_2.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        self.label_3 = QLabel(self.horizontalFrame_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(20, 290, 121, 31))
        self.label_3.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        self.label_4 = QLabel(self.horizontalFrame_2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(20, 340, 151, 31))
        self.label_4.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        self.label_5 = QLabel(self.horizontalFrame_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(180, 240, 151, 31))
        self.label_5.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        self.label_6 = QLabel(self.horizontalFrame_2)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(180, 290, 151, 31))
        self.label_6.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        self.label_7 = QLabel(self.horizontalFrame_2)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(180, 340, 151, 31))
        self.label_7.setStyleSheet(u"font: 75 18pt \"Times New Roman\";")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"PushButton", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"PushButton", None))
        self.pushButton_3.setText(QCoreApplication.translate("MainWindow", u"PushButton", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Dashboard", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Student's Detail", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Name:", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Roll No.:", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Department:", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"......................", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"......................", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"......................", None))
    # retranslateUi

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    MainWindow = QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())






